/** Automatically generated file. DO NOT MODIFY */
package com.example.gpslocator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}