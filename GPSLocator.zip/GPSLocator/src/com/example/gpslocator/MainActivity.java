package com.example.gpslocator;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import android.app.Activity;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

public class MainActivity extends Activity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        updateMap();
    }
    /**
     * To find current location
     * @return
     */
    private LatLng locationFinder(){
    	LatLng currentLocation = null;
    	
    	LocationManager manager= (LocationManager)this.getSystemService(LOCATION_SERVICE);
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setAltitudeRequired(false);
		criteria.setBearingRequired(false);
		criteria.setCostAllowed(true);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		String provider = manager.getBestProvider(criteria, true);
		Location location = manager.getLastKnownLocation(provider);
		double latitude = location.getLatitude();
		double longitude = location.getLongitude();
		currentLocation = new LatLng(latitude,longitude);
    	return currentLocation;
    }
    
    /**
     * To update mapview
     */
    private void updateMap(){
    	GoogleMap map = ((MapFragment) getFragmentManager().findFragmentById(R.id.mapview)).getMap();
        map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        LatLng currentLocation=locationFinder();
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentLocation,19);
        map.animateCamera(update);
        map.addMarker(new MarkerOptions().title("Youre here!").position(currentLocation));
        
    }

}
